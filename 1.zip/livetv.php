

<html lang="en" >
  <head>
	<title>Live TV</title>
	<?php include 'meta.php';?>
  </head>
	<?php include 'header.php';?>
  <body>
	<div class="content">
		<div class="top-head"></div>
			<?php include 'tv1.php';?>
	</div>
  </body>
</html>