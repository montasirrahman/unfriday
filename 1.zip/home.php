<html lang="en" >
  <head>
	<title>UnFriday</title>
	<?php include 'meta.php'; error_reporting(0); ?>
  </head>
	<?php include 'header.php';?>
  <body>
	<div class="content">
<link rel="stylesheet" href="css/home/home.css">
<div class="top-head"></div>
<!---------------Contant---------------------->
<br><br><br><br>
	<?php include 'ytsHome.php';?>
	<?php //include 'discover.php';?>
	<iframe src="1337xTrand.php" class="x1337xTrand" title="description" frameborder="0" scrolling="no" id="iframe"></iframe>
  </body>
</html>



