<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<link rel="stylesheet" href="css/discover/style.css"> 
	<link rel="stylesheet" href="css/color-change/color-change.css">
	<link rel="stylesheet" href="css/suggest/suggest.css">
	<script  src="js/color-change/color-change.js"></script>
<?php include 'meta.php';?>   
            <center>
				<div class="q_s_t">
					<span class="q_s_t_border"></span> 
								COMIGN SOOM
				</div>
			</center>

<!---------
<iframe src="http://tv.ebox.live" allow="fullscreen;" width="100%" style="border: 0px;overflow: hidden;" height="100%" title="description"></iframe>
    --------->