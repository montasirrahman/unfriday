<div class="content_raw" id="demo">
		<?php echo ''.$raw.''; ?>		
</div>