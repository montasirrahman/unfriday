
	<link rel="stylesheet" href="css/search/style-m.css">
		<div class="primary">
			<i class="material-icons search-mobile-icon" id="search">search</i>
		</div>
		<!--------------mobile Search Start------------------->
		<div class="secondary" id="secondary-header">
				<i class="material-icons search-mobile-icon" id="back-arrow">arrow_back</i>
						<div class="search-box-border-m" >
							<form id="searchFormMoblie">
								<select id="selectSiteMobile">
									<option value="search_engine.php?search=">Engine</option>
									<option value="movies.php?query_term=">Movies</option>
								</select><input class="search-input-m" name="search_query_mobile" type="search" maxlength="128" id="query_term2"  placeholder="Search..."/><button class="search-button-m" type="submit"><i class="fas fa-search search-icon-color"></i></button>
							</form>
						</div>
						<div id="results2"></div>
		</div>
		<!--------------mobile Search END------------------->
	<script type="text/javascript" src="js/search-m/search_select.js"></script>
	<script  src="js/search/script-m.js"></script>
	<script type="text/javascript" src="js/search-m/jquery.js"></script>
	<script type="text/javascript" src="js/search-m/auto.js"></script>
	<script type="text/javascript" src="js/search-m/search_select.js"></script>
